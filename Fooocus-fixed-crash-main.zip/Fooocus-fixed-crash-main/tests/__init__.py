import sys
import pathlib

sys.path.append(pathlib.Path(f'{__file__}/../modules').parent.resolve())
